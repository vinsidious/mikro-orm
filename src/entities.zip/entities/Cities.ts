import { Point } from 'geojson';

import {
  Entity,
  ManyToOne,
  OptionalProps,
  PrimaryKey,
  Property,
} from '@mikro-orm/core';

@Entity()
export class Cities {
    [OptionalProps]?: 'createdAt' | 'updatedAt'

    @PrimaryKey()
    id!: string

    @Property()
    countryCode!: string

    @Property()
    location: Point

    @ManyToOne()
    majorCity?: Cities

    @Property()
    population: number

    @Property()
    readableName!: string

    @Property()
    timezone!: string

    @Property()
    createdAt = new Date()

    @Property({ onUpdate: () => new Date() })
    updatedAt = new Date()
}
