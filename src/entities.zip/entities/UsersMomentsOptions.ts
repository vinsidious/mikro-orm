import {
  Entity,
  ManyToOne,
  PrimaryKeyProp,
  Property,
} from '@mikro-orm/core';

import { MomentOptions } from './MomentOptions';
import { Users } from './Users';

@Entity()
export class UsersMomentsOptions {
    [PrimaryKeyProp]?: ['user', 'momentOption']

    @ManyToOne({ primary: true })
    user!: Users

    @ManyToOne({ primary: true })
    momentOption!: MomentOptions

    @Property()
    createdAt = new Date()
}
