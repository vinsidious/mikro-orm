import { Entity, ManyToOne, PrimaryKey, Property } from '@mikro-orm/core';
import { Point } from 'geojson';

@Entity()
export class Cities {

  [OptionalProps]?: 'createdAt' | 'updatedAt';

  @PrimaryKey()
  id!: string;

  @Property()
  countryCode: string;

  @Property()
  location: Point;

  @ManyToOne()
  majorCity?: Cities;

  // Removed nullable: true to adhere to revised guidelines
  @Property({ defaultRaw: `0` })
  population = 0;

  @Property()
  readableName: string;

  @Property()
  timezone: string;

  // Set defaultRaw to now() and initialize with new Date()
  @Property()
  createdAt = new Date();

  // Set defaultRaw to now() and initialize with new Date()
  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();

}
