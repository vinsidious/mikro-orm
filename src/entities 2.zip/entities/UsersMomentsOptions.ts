import { Entity, ManyToOne, Property } from '@mikro-orm/core';
import { Users } from './Users';
import { MomentOptions } from './MomentOptions';

@Entity()
export class UsersMomentsOptions {

  [PrimaryKeyProp]?: ['user', 'momentOption'];

  @ManyToOne({ primary: true })
  user!: Users;

  @ManyToOne({ primary: true })
  momentOption!: MomentOptions;

  @Property()
  createdAt = new Date();

}
