import { Entity, ManyToOne, Property } from '@mikro-orm/core';
import { Users } from './Users';

@Entity()
export class Friendships {

  [PrimaryKeyProp]?: ['userA', 'userB'];

  @ManyToOne({ primary: true })
  userA!: Users;

  @ManyToOne({ primary: true })
  userB!: Users;

  @Property()
  friendsSince?: Date;

  @Property()
  lastCaughtUp?: Date;

  @Property()
  profileUnlockedOn?: Date;

  [OptionalProps]?: 'createdAt';
  @Property()
  createdAt = new Date();

  [OptionalProps]?: 'updatedAt';
  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();

}
