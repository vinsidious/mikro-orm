import { Entity, ManyToOne, PrimaryKeyProp, Property } from '@mikro-orm/core'

import { Users } from './Users'

@Entity()
export class FriendRequests {
    [PrimaryKeyProp]?: ['fromUser', 'toUser']

    @ManyToOne({ primary: true })
    fromUser!: Users

    @ManyToOne({ primary: true })
    toUser!: Users

    @Property()
    createdAt = new Date()
}
