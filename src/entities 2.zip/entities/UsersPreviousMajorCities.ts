import { Entity, Property, ManyToOne } from '@mikro-orm/core';

@Entity()
export class UsersPreviousMajorCities {

  [PrimaryKeyProp]?: ['user', 'majorCity'];

  @ManyToOne({ primary: true })
  user!: Users;

  @ManyToOne({ primary: true })
  majorCity!: Cities;

  @Property()
  leftAt?: Date;

}
