import { Entity, OptionalProps, PrimaryKey, Property, UUIDType } from '@mikro-orm/core';
import { v4 as uuidv4 } from 'uuid';

@Entity()
export class Attributes {

  [OptionalProps]?: 'createdAt' | 'updatedAt';

  @PrimaryKey({ columnType: 'UUID', defaultRaw: `uuid_generate_v4()` }) 
  id = uuidv4();

  @Property()
  attributeName!: string;

  @Property()
  category!: string;

  @Property()
  emojiIcon!: string;

  @Property()
  questionName!: string;

  @Property()
  shortName!: string;

  @Property()
  attributeType!: string;

  @Property()
  createdAt = new Date();

  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();
}
