import { Entity, ManyToOne, Property } from '@mikro-orm/core';
import { MomentOptions } from './MomentOptions';
import { Users } from './Users';

@Entity()
export class UsersMoments {

  [OptionalProps]?: 'createdAt' | 'updatedAt' | 'moreInformation';

  @ManyToOne({ primary: true })
  user!: Users;

  @ManyToOne({ primary: true })
  moment!: MomentOptions;

  @Property()
  createdAt = new Date();

  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();

  @Property()
  moreInformation?: any;

}
