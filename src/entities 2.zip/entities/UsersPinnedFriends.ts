import { Entity, PrimaryKey, ManyToOne, Property, DateType } from '@mikro-orm/core';
import { Users } from './Users';

@Entity()
export class UsersPinnedFriends {

  [PrimaryKeyProp]?: ['user', 'pinnedFriend'];

  @ManyToOne({ primary: true })
  user!: Users;

  @ManyToOne({ primary: true })
  pinnedFriend!: Users;

  @Property({ type: DateType, defaultRaw: `now()` })
  createdAt = new Date();

}
