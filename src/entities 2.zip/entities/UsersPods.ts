import { Entity, ManyToOne, Property } from '@mikro-orm/core';

@Entity()
export class UsersPods {

  [PrimaryKeyProp]?: ['userA', 'userB', 'pod'];

  @ManyToOne({ primary: true })
  userA!: Users;

  @ManyToOne({ primary: true })
  userB!: Users;

  @ManyToOne({ primary: true })
  pod!: Pods;

  @Property()
  createdAt = new Date();
}
