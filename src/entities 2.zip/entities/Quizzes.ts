import { Entity, ManyToOne, OptionalProps, PrimaryKey, Property } from '@mikro-orm/core';
import { v4 as uuidv4 } from 'uuid';
import { Users } from './Users';
import { Cards } from './Cards';

@Entity()
export class Quizzes {

  [OptionalProps]?: 'createdAt' | 'updatedAt';

  @PrimaryKey({ columnType: 'UUID' })
  id = uuidv4();

  @ManyToOne()
  actor?: Users;

  @ManyToOne()
  subject?: Users;

  @ManyToOne()
  currentQuizCard?: Cards;

  @Property()
  lastActorQuizAt = new Date();

  @Property()
  createdAt = new Date();

  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();

}
