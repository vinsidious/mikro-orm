import { Entity, ManyToOne, PrimaryKey, Property } from '@mikro-orm/core';

@Entity()
export class Invites {

    [OptionalProps]?: 'createdAt' | 'updatedAt';
  
    @PrimaryKey()
    id!: string;
  
    @ManyToOne()
    inviter?: Users;
  
    @ManyToOne()
    consumer?: Users;
  
    @Property()
    createdAt = new Date();
  
    @Property({ onUpdate: () => new Date() })
    updatedAt = new Date();
  
}
