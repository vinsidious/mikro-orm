import { Entity, PrimaryKey, Property, ManyToOne, OptionalProps } from '@mikro-orm/core';
import { Users } from './Users';
import { v4 as uuidv4 } from 'uuid';

@Entity()
export class Popups {

  [OptionalProps]?: 'createdAt' | 'updatedAt' | 'id';

  @PrimaryKey({ columnType: 'UUID' })
  id = uuidv4();

  @ManyToOne()
  user!: Users;

  @Property()
  popupName!: string;

  @Property()
  popupType!: string;

  @Property()
  startedAt!: Date;

  @Property()
  endedEarlyAt?: Date;

  @Property()
  expiredAt!: Date;

  @Property()
  createdAt = new Date();

  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();

}
