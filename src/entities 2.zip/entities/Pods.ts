import { Entity, PrimaryKey, Property } from '@mikro-orm/core';
import { v4 as uuidv4 } from 'uuid';

@Entity()
export class Pods {

  [OptionalProps]?: 'createdAt' | 'updatedAt';

  @PrimaryKey({ columnType: 'UUID' })
  id = uuidv4();

  @Property()
  emojiIcon?: string;

  @Property()
  podName: string;

  @Property()
  createdAt = new Date();

  @Property({ onUpdate: () => new Date() })
  updatedAt = new Date();

}
