import {
    DateType,
    Entity,
    ManyToOne,
    OneToOne,
    OptionalProps,
    Property,
} from '@mikro-orm/core'

import { Cards } from './Cards'
import { Users } from './Users'

@Entity()
export class UsersQuizNotes {
    [OptionalProps]?: 'user' | 'createdAt' | 'updatedAt'

    @OneToOne({ primary: true })
    user!: Users

    @ManyToOne()
    currentQuizCard?: Cards

    @Property({ type: DateType })
    lastUserQuizAt?: Date

    @Property()
    quizNoteAttributes?: any

    @Property()
    createdAt = new Date()

    @Property({ onUpdate: () => new Date() })
    updatedAt = new Date()
}
